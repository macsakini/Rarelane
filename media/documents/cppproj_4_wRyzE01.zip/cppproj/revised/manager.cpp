//Name: Manager.h
//Project: CMSC 202 Project 3, Fall 2021
//Author:  Jeremy Dixon
//Date:    10/14/21
//Desc: This file contains the header details for the Manager class

#include "Item.h"
#include "Schedule.h"

#include <fstream>
#include <string>
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;

class Manager {
 public:
  void DisplaySchedules(string name){

    std::ifstream f("proj3_schedule2.txt");

    std::string line;
      // read each line
    while (std::getline(f, line)) {

        std::string token;
        std::istringstream ss(line);
        vector<string>result;

        // then read each element by delimiter
        while (std::getline(ss, token, '\n'))
        cout<<"\n"<<endl;
        result.push_back(token);
            for (int i = 0; i < result.size(); i++) {
                if(result[i].find(name) == 0){
                    std::cout << result[i] << std::endl;
                }else{
                std::cout << "-" << std::endl;   
                }

            }
        }

        f.close();
  }


  void ReadFile(){

      std::ifstream f("proj3_schedule2.txt");

      std::string line;

      cout << "File opend successfully";
  }

  void InsertNewItem(string Name, string Activity, int Time){
    ofstream file;
    
    file.open("proj3_schedule2.txt");

    file << Name << " ; " << Time << " ; " << Activity;
    
    cout << "String inserted successfully";
  }
  
  int FindSchedule(string schedName){

  }

  void MainMenu(){

    cout << "1. Display Schedules\n2. Reverse Schedule\n3. Insert New Item\n4. Exit.\n";

  }

  void ReverseSchedule(){

      cout << "Schedule has been reversed successfully";

  }
private:
  vector<Schedule*> m_schedules; //Vector of all schedules
  string m_fileName; //File to read in
};

int main(){
    int input;
    cout << MainMenu();
    cin >> input;

    if (input == 1){
        string name;

        cout << "Name of Person with Schedule\n";

        cin >> name;

        open_file(name);

        ScheduleManager SM ;
    }
    
    else if(input == 2){
        InsertSchedule IS ;
        cout << "Insert name of Person";
        cin >> IS.Name;
        cout << "Type Activity to be Scheduled";
        cin >> IS.Activity;
        cout << "Insert Time of Activity";
        cin >> IS.Time;

        InsertActivity(IS.Name, IS.Activity, IS.Time);

        cout << IS.Name << ";" << IS.Time << ";" << IS.Activity << endl;
        cout << "New Activity Inserted Sucessfully";
    }
    
    else{
        ReverseSchedule RS;
        cout << "3" << endl;
    }

    system("pause>0");
}