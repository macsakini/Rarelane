#include <iostream>
#include <string>
using namespace std;

class Item{
 public:
  Item();
  
  string name;
  
  int time;

  Item(string, int);


  string GetName(){
      string name;
      
      cout << "Enter Name";
      
      cin >> name;
      
      return name;
  }

  int GetTime(){
      int time;
      
      cout << "Enter Time";
      
      cin >> time;
      
      return time;
  }

  Item* GetNext(){
      
    string name = GetName();

    cout << name << ";" << GetTime() << '\n';
      

  }

  void SetName(string name){

      string name = GetName();
  }

  void SetTime(int time){

     int time = GetTime();

  }
  void SetNext(Item*){

  }

  friend ostream &operator<< (ostream &output, Item &myItem){
    output << myItem.m_time << " : " << myItem.m_name;
    return output;
  }
private:
  string m_name; //Name of the activity
  int m_time; //Time activity starts
  Item* m_next; //Pointer to next node in linked list
};


