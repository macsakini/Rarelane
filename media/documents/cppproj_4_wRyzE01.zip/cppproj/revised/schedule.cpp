#include <string>
#include <iostream>
#include <iomanip>
#include <cmath>
#include "Item.h"
#include <fstream>
using namespace std;

class Schedule {
 public:

  Schedule();

  Schedule(string);

  void InsertSorted(string Name, string Activity, int Time){
    ofstream file;
    
    file.open("proj3_schedule2.txt");

    file << Name << " ; " << Time << " ; " << Activity;
    
    cout << "String inserted successfully";

  }

  string GetName();

  int GetSize();

  void ReverseSchedule();

  Item* GetData(int nodeNum);

  friend ostream &operator<< (ostream &output, Schedule &mySchedule);
 private:
  string m_name; //Name of the Schedule
  Item *m_head; //Front of the Schedule
  Item *m_tail; //End of the Schedule
  int m_size; //Total size of the Schedule
};
